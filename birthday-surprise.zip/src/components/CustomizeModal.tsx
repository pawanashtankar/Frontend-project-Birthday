import React, { useState } from "react";
import { BirthdayConfig } from "../birthdayConfig";
import { X, Check, RotateCcw, Heart, SlidersHorizontal } from "lucide-react";
import { soundManager } from "../utils/audio";

interface CustomizeModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: BirthdayConfig;
  onSave: (updated: BirthdayConfig) => void;
  onReset: () => void;
}

export const CustomizeModal: React.FC<CustomizeModalProps> = ({
  isOpen,
  onClose,
  config,
  onSave,
  onReset,
}) => {
  const [formData, setFormData] = useState<BirthdayConfig>(config);

  if (!isOpen) return null;

  const handleChange = (field: keyof BirthdayConfig, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playChime();
    onSave(formData);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="bg-[#FFFDF5] max-w-xl w-full max-h-[90vh] rounded-3xl p-6 sm:p-8 shadow-2xl border-2 border-[#C94343]/20 overflow-y-auto relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-2 mb-4">
          <div className="p-2 bg-[#FFE7DC] rounded-xl text-[#C94343]">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-handwriting text-2xl sm:text-3xl font-bold text-[#A92F35]">
              Personalize Surprise
            </h2>
            <p className="text-xs text-stone-500 font-body">
              Customize names, messages, and wishes in real-time
            </p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          {/* Recipient & Sender Names */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1 font-body">
                Recipient Name
              </label>
              <input
                type="text"
                value={formData.RECIPIENT_NAME}
                onChange={(e) => handleChange("RECIPIENT_NAME", e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-white border border-stone-300 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-[#C94343]/40 focus:border-[#C94343]"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1 font-body">
                Your Name
              </label>
              <input
                type="text"
                value={formData.YOUR_NAME}
                onChange={(e) => handleChange("YOUR_NAME", e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-white border border-stone-300 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-[#C94343]/40 focus:border-[#C94343]"
                required
              />
            </div>
          </div>

          {/* Birthday Message on Card */}
          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1 font-body">
              Main Birthday Card Greeting
            </label>
            <textarea
              rows={2}
              value={formData.BIRTHDAY_MESSAGE}
              onChange={(e) => handleChange("BIRTHDAY_MESSAGE", e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-white border border-stone-300 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-[#C94343]/40 focus:border-[#C94343]"
            />
          </div>

          {/* Gift 1 Message */}
          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1 font-body">
              Gift #1 Message (Golden Wish)
            </label>
            <textarea
              rows={2}
              value={formData.GIFT_1_MESSAGE}
              onChange={(e) => handleChange("GIFT_1_MESSAGE", e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-white border border-stone-300 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-[#C94343]/40 focus:border-[#C94343]"
            />
          </div>

          {/* Gift 2 Message */}
          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1 font-body">
              Gift #2 Message (Photo Memory Note)
            </label>
            <textarea
              rows={2}
              value={formData.GIFT_2_MESSAGE}
              onChange={(e) => handleChange("GIFT_2_MESSAGE", e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-white border border-stone-300 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-[#C94343]/40 focus:border-[#C94343]"
            />
          </div>

          {/* Gift 3 Message */}
          <div>
            <label className="block text-xs font-bold text-stone-700 uppercase tracking-wider mb-1 font-body">
              Gift #3 Message (Secret Note)
            </label>
            <textarea
              rows={2}
              value={formData.GIFT_3_MESSAGE}
              onChange={(e) => handleChange("GIFT_3_MESSAGE", e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-white border border-stone-300 text-stone-800 text-sm focus:outline-none focus:ring-2 focus:ring-[#C94343]/40 focus:border-[#C94343]"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-stone-200">
            <button
              type="button"
              onClick={() => {
                onReset();
                onClose();
              }}
              className="w-full sm:w-auto px-4 py-2 rounded-full text-stone-600 bg-stone-100 hover:bg-stone-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Defaults</span>
            </button>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 sm:flex-none px-5 py-2 rounded-full border border-stone-300 text-stone-700 text-sm font-semibold hover:bg-stone-50 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 sm:flex-none px-6 py-2 rounded-full bg-[#C94343] hover:bg-[#A92F35] text-white text-sm font-bold shadow-md flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>Save Changes</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
