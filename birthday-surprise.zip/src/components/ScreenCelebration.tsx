import React, { useEffect } from "react";
import { soundManager } from "../utils/audio";
import { fireBirthdayConfetti, fireHeartConfetti } from "../utils/confetti";
import { Sparkles, Heart, RotateCcw, Image as ImageIcon, Mail, SlidersHorizontal } from "lucide-react";

interface ScreenCelebrationProps {
  onRestart: () => void;
  onGoToMemories: () => void;
  onGoToLetter: () => void;
  onOpenCustomize: () => void;
  recipientName: string;
  yourName: string;
}

export const ScreenCelebration: React.FC<ScreenCelebrationProps> = ({
  onRestart,
  onGoToMemories,
  onGoToLetter,
  onOpenCustomize,
  recipientName,
  yourName,
}) => {
  useEffect(() => {
    fireBirthdayConfetti();
    const timer = setTimeout(() => {
      fireHeartConfetti();
    }, 700);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="w-full max-w-2xl mx-auto paper-card bg-[#FFFDF5] rounded-3xl p-6 sm:p-10 relative overflow-hidden border border-[#C94343]/20 shadow-2xl text-center">
      {/* Decorative dashed card border */}
      <div className="absolute inset-4 border-2 border-dashed border-[#F8D9DC] rounded-2xl pointer-events-none" />

      {/* Confetti blast header */}
      <div className="relative inline-flex items-center gap-2 px-5 py-1.5 bg-[#FFE7DC] text-[#C94343] rounded-full border border-[#C94343]/20 shadow-xs mb-3">
        <Sparkles className="w-4 h-4 text-[#C94343]" />
        <span className="font-handwriting text-lg sm:text-xl font-bold">
          Happy Birthday, {recipientName}!
        </span>
        <Sparkles className="w-4 h-4 text-[#C94343]" />
      </div>

      <h1 className="font-cursive text-5xl sm:text-6xl md:text-7xl font-bold text-[#A92F35] mt-1 mb-3">
        Here's to You! 🥂✨
      </h1>

      <p className="font-handwriting text-2xl sm:text-3xl text-stone-700 max-w-lg mx-auto leading-relaxed my-4">
        May your day be filled with warm smiles, sweet slices of cake, and memories that stay with you forever!
      </p>

      {/* Cute Celebration Badges / Floating Icons */}
      <div className="flex items-center justify-center gap-4 my-6 select-none">
        <div className="w-14 h-14 bg-rose-100 rounded-2xl flex items-center justify-center text-3xl shadow-xs border border-rose-200 rotate-[-4deg]">
          🎂
        </div>
        <div className="w-16 h-16 bg-amber-100 rounded-2xl flex items-center justify-center text-3xl shadow-sm border border-amber-200 animate-bounce">
          🎉
        </div>
        <div className="w-14 h-14 bg-pink-100 rounded-2xl flex items-center justify-center text-3xl shadow-xs border border-pink-200 rotate-[4deg]">
          💖
        </div>
      </div>

      {/* Quick Access Action Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-6 text-left">
        <button
          onClick={() => {
            soundManager.playPop();
            onGoToMemories();
          }}
          className="p-3.5 bg-white rounded-xl border border-stone-200 hover:border-[#C94343]/40 shadow-xs hover:shadow-md transition-all text-left flex items-start gap-3 cursor-pointer group"
        >
          <div className="p-2 bg-rose-50 text-[#C94343] rounded-lg group-hover:scale-110 transition-transform">
            <ImageIcon className="w-5 h-5" />
          </div>
          <div>
            <p className="font-handwriting text-lg font-bold text-stone-800 leading-none">
              Photo Memories
            </p>
            <p className="text-[11px] text-stone-500 font-body mt-1">Re-visit scrapbook</p>
          </div>
        </button>

        <button
          onClick={() => {
            soundManager.playPop();
            onGoToLetter();
          }}
          className="p-3.5 bg-white rounded-xl border border-stone-200 hover:border-[#C94343]/40 shadow-xs hover:shadow-md transition-all text-left flex items-start gap-3 cursor-pointer group"
        >
          <div className="p-2 bg-rose-50 text-[#C94343] rounded-lg group-hover:scale-110 transition-transform">
            <Mail className="w-5 h-5" />
          </div>
          <div>
            <p className="font-handwriting text-lg font-bold text-stone-800 leading-none">
              Special Letter
            </p>
            <p className="text-[11px] text-stone-500 font-body mt-1">Read words from heart</p>
          </div>
        </button>

        <button
          onClick={() => {
            soundManager.playPop();
            onOpenCustomize();
          }}
          className="p-3.5 bg-white rounded-xl border border-stone-200 hover:border-[#C94343]/40 shadow-xs hover:shadow-md transition-all text-left flex items-start gap-3 cursor-pointer group"
        >
          <div className="p-2 bg-amber-50 text-amber-700 rounded-lg group-hover:scale-110 transition-transform">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
          <div>
            <p className="font-handwriting text-lg font-bold text-stone-800 leading-none">
              Personalize
            </p>
            <p className="text-[11px] text-stone-500 font-body mt-1">Change names & text</p>
          </div>
        </button>
      </div>

      {/* Primary Restart Button */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t border-[#F8D9DC]">
        <button
          onClick={() => {
            soundManager.playChime();
            onRestart();
          }}
          className="w-full sm:w-auto px-8 py-3.5 rounded-full bg-[#C94343] text-white font-body font-bold text-base shadow-md hover:bg-[#A92F35] active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer hover:shadow-lg hover:shadow-[#C94343]/30"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Replay The Whole Surprise</span>
        </button>
      </div>

      <p className="mt-4 text-xs font-handwriting text-stone-400">
        Created for {recipientName} by {yourName} with endless love ❤️
      </p>
    </div>
  );
};
