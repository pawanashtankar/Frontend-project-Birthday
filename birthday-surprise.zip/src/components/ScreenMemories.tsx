import React, { useState } from "react";
import { soundManager } from "../utils/audio";
import { MemoryPhoto } from "../birthdayConfig";
import { Sparkles, Heart, X, ArrowRight, Eye } from "lucide-react";

interface ScreenMemoriesProps {
  onContinue: () => void;
  memories: MemoryPhoto[];
}

export const ScreenMemories: React.FC<ScreenMemoriesProps> = ({ onContinue, memories }) => {
  const [selectedPhoto, setSelectedPhoto] = useState<MemoryPhoto | null>(null);

  const handleOpenPhoto = (photo: MemoryPhoto) => {
    soundManager.playPop();
    setSelectedPhoto(photo);
  };

  const handleCloseModal = () => {
    soundManager.playPop();
    setSelectedPhoto(null);
  };

  return (
    <div className="w-full max-w-4xl mx-auto paper-card bg-[#FFFDF5] rounded-3xl p-6 sm:p-8 md:p-10 relative overflow-hidden border border-[#C94343]/20 shadow-xl text-center">
      {/* Decorative dashed card border */}
      <div className="absolute inset-3 border-2 border-dashed border-[#F8D9DC] rounded-2xl pointer-events-none" />

      {/* Header section */}
      <div className="relative mb-8">
        <div className="inline-flex items-center gap-2 px-4 py-1 bg-[#FFE7DC] text-[#C94343] rounded-full border border-[#C94343]/20 shadow-xs mb-2">
          <Sparkles className="w-4 h-4 text-[#C94343]" />
          <span className="font-handwriting text-lg font-bold">Cherished Moments</span>
          <Sparkles className="w-4 h-4 text-[#C94343]" />
        </div>

        <h1 className="font-cursive text-5xl sm:text-6xl md:text-7xl font-bold text-[#A92F35] tracking-wide">
          MEMORIES
        </h1>
        <p className="font-handwriting text-xl text-stone-600 max-w-md mx-auto mt-1">
          Every picture holds a thousand laughs and a memory I will keep forever.
        </p>
      </div>

      {/* Hanging Clothesline / Twine String Representation */}
      <div className="relative my-8 px-2">
        {/* Twine line */}
        <div className="w-full h-1 bg-amber-900/30 rounded-full shadow-xs mb-6 relative">
          {/* Wooden pegs / clips along the line */}
          <div className="absolute -top-3 left-[15%] w-3 h-6 bg-amber-700 rounded-xs shadow-xs" />
          <div className="absolute -top-3 left-[38%] w-3 h-6 bg-amber-700 rounded-xs shadow-xs" />
          <div className="absolute -top-3 left-[62%] w-3 h-6 bg-amber-700 rounded-xs shadow-xs" />
          <div className="absolute -top-3 left-[85%] w-3 h-6 bg-amber-700 rounded-xs shadow-xs" />
        </div>

        {/* Polaroid Scrapbook Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-2">
          {memories.map((mem, index) => (
            <div
              key={mem.id}
              onClick={() => handleOpenPhoto(mem)}
              style={
                {
                  "--rot": `${mem.rotation}deg`,
                  transform: `rotate(${mem.rotation}deg)`,
                } as React.CSSProperties
              }
              className="group cursor-pointer bg-white p-3 pb-6 rounded-md shadow-md hover:shadow-xl border border-stone-200 transition-all duration-300 hover:scale-105 hover:z-20 relative animate-swing"
            >
              {/* Wooden Pin / Clip graphic at top */}
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center">
                <div className="w-4 h-6 bg-amber-200 border border-amber-400 rounded-t-xs shadow-xs flex items-center justify-center text-[10px]">
                  📌
                </div>
              </div>

              {/* Red-and-White Checkered Photo Border Accent */}
              <div className="p-1.5 gingham-pattern rounded-xs mb-2 border border-red-200">
                <div className="aspect-4/3 w-full bg-stone-100 rounded-xs overflow-hidden relative">
                  <img
                    src={mem.url}
                    alt={mem.caption}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  {/* Subtle view hover overlay */}
                  <div className="absolute inset-0 bg-black/25 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
                    <Eye className="w-6 h-6 drop-shadow-md" />
                  </div>
                </div>
              </div>

              {/* Polaroid Caption */}
              <div className="text-left px-1 mt-2">
                <p className="font-handwriting text-base text-stone-800 font-bold line-clamp-2 leading-snug">
                  {mem.caption}
                </p>
                {mem.date && (
                  <p className="text-[11px] text-[#C94343] font-body mt-1 font-semibold">
                    {mem.date}
                  </p>
                )}
              </div>

              {/* Decorative mini stickers in corners */}
              {index % 2 === 0 ? (
                <div className="absolute -bottom-1 -right-1 text-xs">🌸</div>
              ) : (
                <div className="absolute -bottom-1 -left-1 text-xs">🎀</div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Button to proceed to handwritten letter */}
      <div className="flex justify-center mt-8 pt-4 border-t border-[#F8D9DC]">
        <button
          onClick={() => {
            soundManager.playChime();
            onContinue();
          }}
          className="group px-8 py-3 rounded-full bg-[#C94343] text-white font-body font-bold text-base shadow-md hover:bg-[#A92F35] active:scale-95 transition-all flex items-center gap-2 cursor-pointer hover:shadow-lg hover:shadow-[#C94343]/30"
        >
          <Heart className="w-4 h-4 fill-white" />
          <span>Read My Letter</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

      {/* ENLARGED PHOTO MODAL */}
      {selectedPhoto && (
        <div
          className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in"
          onClick={handleCloseModal}
        >
          <div
            className="bg-white max-w-lg w-full p-4 sm:p-6 pb-8 rounded-2xl shadow-2xl border-2 border-stone-200 relative text-center"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close button */}
            <button
              onClick={handleCloseModal}
              className="absolute top-3 right-3 p-2 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-600 transition-colors cursor-pointer"
              aria-label="Close photo preview"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Checkered Frame */}
            <div className="p-2 gingham-pattern rounded-lg mb-4 border border-rose-300">
              <div className="aspect-4/3 w-full rounded-md overflow-hidden bg-stone-100 shadow-inner">
                <img
                  src={selectedPhoto.url}
                  alt={selectedPhoto.caption}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            {/* Photo Caption & Date */}
            <h3 className="font-handwriting text-2xl sm:text-3xl text-stone-900 font-bold mt-2">
              {selectedPhoto.caption}
            </h3>
            {selectedPhoto.date && (
              <span className="inline-block mt-2 px-3 py-1 bg-[#FFE7DC] text-[#A92F35] text-xs font-semibold rounded-full">
                Captured on {selectedPhoto.date}
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
