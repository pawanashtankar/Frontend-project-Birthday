import React, { useState } from "react";
import { soundManager } from "../utils/audio";
import { fireBirthdayConfetti, fireHeartConfetti } from "../utils/confetti";
import { Sparkles, Heart, Wind, ArrowRight } from "lucide-react";

interface ScreenMakeAWishProps {
  onContinue: () => void;
  recipientName: string;
}

export const ScreenMakeAWish: React.FC<ScreenMakeAWishProps> = ({ onContinue, recipientName }) => {
  // 5 candles on the cake
  const [candles, setCandles] = useState([true, true, true, true, true]);
  const [hasMadeWish, setHasMadeWish] = useState(false);

  const areAllCandlesBlown = candles.every((c) => !c);

  const blowOutCandle = (index: number) => {
    if (!candles[index]) return;
    soundManager.playPop();
    const newCandles = [...candles];
    newCandles[index] = false;
    setCandles(newCandles);

    if (newCandles.every((c) => !c)) {
      triggerWishComplete();
    }
  };

  const blowOutAll = () => {
    soundManager.playBlowOut();
    setCandles([false, false, false, false, false]);
    triggerWishComplete();
  };

  const triggerWishComplete = () => {
    setHasMadeWish(true);
    soundManager.playChime();
    fireBirthdayConfetti();
    setTimeout(() => {
      fireHeartConfetti();
    }, 400);
  };

  const candleColors = ["#F472B6", "#60A5FA", "#FBBF24", "#34D399", "#A78BFA"];

  return (
    <div className="w-full max-w-lg mx-auto paper-card bg-[#FFFDF5] rounded-3xl p-6 sm:p-8 relative overflow-hidden border border-[#C94343]/20 text-center">
      {/* Decorative inner stamp border */}
      <div className="absolute inset-2 border-2 border-dashed border-[#F8D9DC] rounded-2xl pointer-events-none" />

      {/* Decorative top badge */}
      <div className="relative inline-flex items-center justify-center gap-1.5 px-4 py-1 bg-[#FFE7DC] text-[#C94343] font-handwriting text-lg rounded-full mb-2 shadow-xs border border-[#C94343]/15">
        <Sparkles className="w-4 h-4 text-[#C94343]" />
        <span>Close your eyes & dream big</span>
        <Sparkles className="w-4 h-4 text-[#C94343]" />
      </div>

      {/* Heading */}
      <h1 className="font-handwriting text-4xl sm:text-5xl font-bold text-[#A92F35] tracking-wide mb-1">
        MAKE A WISH
      </h1>
      <p className="font-body text-xs sm:text-sm text-stone-600 max-w-xs mx-auto mb-6">
        {hasMadeWish
          ? "✨ Your wish is sealed with love! ✨"
          : `Take a deep breath, make your sweetest wish for this year, ${recipientName}!`}
      </p>

      {/* Interactive Birthday Cake Illustration */}
      <div className="relative my-4 flex flex-col items-center justify-center">
        {/* Decorative Sparkles & Hearts floating */}
        <div className="absolute -top-3 left-8 text-amber-400 animate-pulse pointer-events-none">
          <Sparkles className="w-6 h-6" />
        </div>
        <div className="absolute top-2 right-10 text-rose-400 animate-bounce pointer-events-none">
          <Heart className="w-5 h-5 fill-rose-300 text-rose-400" />
        </div>

        {/* Cake Container */}
        <div className="relative w-72 h-56 flex flex-col items-center justify-end select-none">
          {/* Row of Candles */}
          <div className="flex items-end justify-center gap-4 z-20 mb-[-4px]">
            {candles.map((isLit, i) => (
              <div
                key={i}
                onClick={() => blowOutCandle(i)}
                className="group relative flex flex-col items-center cursor-pointer select-none transition-transform active:scale-95"
                title={isLit ? "Click to blow out this candle" : "Blown out"}
              >
                {/* Flame or Smoke puff */}
                {isLit ? (
                  <div className="relative flex flex-col items-center -mb-1 animate-flame">
                    {/* Outer glow aura */}
                    <div className="absolute -top-1 w-5 h-6 bg-amber-300/40 rounded-full blur-xs pointer-events-none" />
                    {/* Flame shape */}
                    <div className="w-3.5 h-6 bg-gradient-to-t from-amber-500 via-yellow-400 to-orange-200 rounded-full rounded-t-full shadow-md" />
                    {/* Inner flame core */}
                    <div className="absolute bottom-0.5 w-1.5 h-3 bg-white rounded-full opacity-90" />
                  </div>
                ) : (
                  <div className="h-6 flex items-center justify-center">
                    <span className="text-xs text-stone-400 animate-fade-in italic">💨</span>
                  </div>
                )}

                {/* Candle Wick */}
                <div className="w-0.5 h-1.5 bg-stone-700" />

                {/* Candle Body */}
                <div
                  className="w-3.5 h-12 rounded-t-sm shadow-xs border border-black/10 relative overflow-hidden"
                  style={{ backgroundColor: candleColors[i] }}
                >
                  {/* Candle diagonal stripes */}
                  <div className="absolute inset-0 opacity-40 bg-[repeating-linear-gradient(45deg,transparent,transparent_4px,white_4px,white_8px)]" />
                </div>
              </div>
            ))}
          </div>

          {/* Top Cake Tier (Frosting + Strawberry/Cherry toppings) */}
          <div className="relative w-44 h-16 bg-[#FFF9F9] rounded-t-2xl shadow-sm border-2 border-rose-200 z-10 flex items-center justify-center overflow-hidden">
            {/* Scalloped Icing drips */}
            <div className="absolute -top-1 left-0 right-0 flex justify-between px-2">
              <span className="text-sm">🍓</span>
              <span className="text-sm">✨</span>
              <span className="text-sm">🍓</span>
              <span className="text-sm">✨</span>
              <span className="text-sm">🍓</span>
            </div>
            {/* Cream Swirl layer */}
            <div className="w-full h-4 bg-[#F8D9DC]/70 absolute top-5" />
            <span className="font-handwriting text-rose-400 font-bold text-sm tracking-wider z-10 pt-2">
              ♥ LOVE & JOY ♥
            </span>
          </div>

          {/* Bottom Cake Tier */}
          <div className="relative w-60 h-20 bg-gradient-to-b from-[#FFE7DC] to-[#F8D9DC] rounded-b-2xl rounded-t-md shadow-md border-2 border-rose-200 flex flex-col justify-center items-center overflow-hidden">
            {/* Gingham style ribbon belt around cake */}
            <div className="w-full h-3 gingham-pattern border-y border-[#C94343]/30 my-1" />
            <div className="flex gap-2 text-rose-400 text-xs font-handwriting">
              <span>★</span>
              <span>Happy Birthday</span>
              <span>★</span>
            </div>
          </div>

          {/* Cake Stand / Plate */}
          <div className="w-72 h-3 bg-white rounded-full shadow-md border border-stone-200 mt-[-2px] relative z-0">
            <div className="w-20 h-2 bg-stone-100 rounded-b-md mx-auto shadow-xs border-x border-b border-stone-200" />
          </div>
        </div>
      </div>

      {/* Interactive Helper Text */}
      <p className="font-handwriting text-lg text-stone-600 my-2">
        {!areAllCandlesBlown ? (
          <span>Tap each candle to blow it out, or blow them all at once!</span>
        ) : (
          <span className="text-[#C94343] font-bold text-xl">
            🎉 All candles blown out! Your birthday wish is in motion! 💖
          </span>
        )}
      </p>

      {/* Buttons */}
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-4 pt-2">
        {!areAllCandlesBlown && (
          <button
            onClick={blowOutAll}
            className="w-full sm:w-auto px-6 py-2.5 rounded-full bg-[#FFE7DC] hover:bg-[#F8D9DC] text-[#A92F35] font-body font-semibold text-sm border border-[#C94343]/20 shadow-xs active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Wind className="w-4 h-4 text-[#C94343]" />
            <span>Blow Out All Candles</span>
          </button>
        )}

        <button
          onClick={() => {
            soundManager.playChime();
            onContinue();
          }}
          className="w-full sm:w-auto px-7 py-3 rounded-full bg-[#C94343] text-white font-body font-bold text-base shadow-md hover:bg-[#A92F35] active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer hover:shadow-lg hover:shadow-[#C94343]/25"
        >
          <span>Open Birthday Card</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
