import React, { useState, useEffect } from "react";
import { soundManager } from "../utils/audio";
import { fireHeartConfetti, fireBirthdayConfetti } from "../utils/confetti";
import { Sparkles, Heart, ArrowRight, FastForward } from "lucide-react";

interface ScreenLetterProps {
  onContinue: () => void;
  recipientName: string;
  yourName: string;
  letterTitle: string;
  letterParagraphs: string[];
  cartoonImage: string;
}

export const ScreenLetter: React.FC<ScreenLetterProps> = ({
  onContinue,
  recipientName,
  yourName,
  letterTitle,
  letterParagraphs,
  cartoonImage,
}) => {
  // Reveal paragraphs sequentially like a letter being typed / read
  const [revealedCount, setRevealedCount] = useState(1);
  const [isFullyRevealed, setIsFullyRevealed] = useState(false);

  useEffect(() => {
    if (revealedCount < letterParagraphs.length) {
      const timer = setTimeout(() => {
        setRevealedCount((prev) => prev + 1);
        soundManager.playSparkle();
      }, 1100);
      return () => clearTimeout(timer);
    } else {
      setIsFullyRevealed(true);
      fireHeartConfetti();
    }
  }, [revealedCount, letterParagraphs.length]);

  const handleSkipAnimation = () => {
    setRevealedCount(letterParagraphs.length);
    setIsFullyRevealed(true);
    fireHeartConfetti();
  };

  return (
    <div className="w-full max-w-2xl mx-auto paper-card bg-white rounded-3xl p-6 sm:p-10 md:p-12 relative overflow-hidden border border-[#C94343]/20 shadow-2xl transition-all duration-300">
      {/* Top and Bottom Gingham border tape */}
      <div className="absolute top-0 left-0 right-0 h-4 gingham-pattern border-b border-[#C94343]/25" />
      <div className="absolute bottom-0 left-0 right-0 h-4 gingham-pattern border-t border-[#C94343]/25" />

      {/* Decorative Stamp border */}
      <div className="absolute inset-4 border border-dashed border-[#F8D9DC] rounded-2xl pointer-events-none" />

      {/* Top Header Row with Stamp & Cursive Title */}
      <div className="relative flex items-center justify-between border-b border-rose-100 pb-4 mb-6">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#C94343] font-body font-bold">
            A Handwritten Letter For You
          </span>
          <h1 className="font-cursive text-4xl sm:text-5xl font-bold text-[#A92F35] mt-1">
            {letterTitle}
          </h1>
        </div>

        {/* Vintage Postmark / Stamp */}
        <div className="w-14 h-16 bg-[#FFF9F9] border-2 border-dashed border-[#C94343]/40 rounded p-1 flex flex-col items-center justify-center rotate-3 shadow-xs">
          <Heart className="w-5 h-5 text-[#C94343] fill-[#C94343]" />
          <span className="text-[9px] text-[#A92F35] font-body font-bold mt-1">AIR MAIL</span>
        </div>
      </div>

      {/* Cute corner character mascot */}
      <div className="absolute bottom-16 right-6 w-20 h-20 rounded-full border-2 border-rose-200 overflow-hidden shadow-md hidden sm:block rotate-3 bg-[#FFFDF5] p-0.5">
        <img
          src={cartoonImage}
          alt="Letter mascot"
          className="w-full h-full object-cover rounded-full"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Letter Body Content with Progressive Reveal */}
      <div className="relative space-y-4 text-left my-6 sm:pr-16 min-h-[300px]">
        {letterParagraphs.map((para, index) => {
          const isVisible = index < revealedCount;
          // Replace name placeholder dynamically if present
          const formattedText = para
            .replace(/\[RECIPIENT_NAME\]/g, recipientName)
            .replace(/Emma/g, recipientName)
            .replace(/\[YOUR_NAME\]/g, yourName);

          return (
            <div
              key={index}
              className={`transition-all duration-700 ${
                isVisible
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-3 pointer-events-none"
              }`}
            >
              <p className="font-handwriting text-xl sm:text-2xl text-stone-800 leading-relaxed">
                {formattedText}
              </p>
            </div>
          );
        })}

        {/* Sign-off / With lots of love */}
        {isFullyRevealed && (
          <div className="pt-6 animate-fade-in text-left">
            <p className="font-handwriting text-2xl text-stone-700">With all my love,</p>
            <p className="font-cursive text-4xl text-[#C94343] font-bold mt-1">
              {yourName} ❤️
            </p>
          </div>
        )}
      </div>

      {/* Final Animated Pulsing Heart at Bottom */}
      <div className="relative flex flex-col items-center justify-center my-6">
        <div className="relative w-14 h-14 flex items-center justify-center">
          <div className="absolute inset-0 bg-rose-200 rounded-full animate-ping opacity-40" />
          <div className="w-12 h-12 bg-gradient-to-tr from-[#C94343] to-rose-400 rounded-full flex items-center justify-center text-white shadow-md">
            <Heart className="w-6 h-6 fill-white" />
          </div>
        </div>
        <span className="font-handwriting text-base text-[#A92F35] font-bold mt-1">
          Forever & Always
        </span>
      </div>

      {/* Action Controls */}
      <div className="relative flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t border-rose-100">
        {!isFullyRevealed && (
          <button
            onClick={handleSkipAnimation}
            className="px-4 py-2 text-xs text-stone-500 hover:text-stone-800 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <FastForward className="w-3.5 h-3.5" />
            <span>Show Full Letter</span>
          </button>
        )}

        <button
          onClick={() => {
            soundManager.playChime();
            fireBirthdayConfetti();
            onContinue();
          }}
          className="group px-8 py-3 rounded-full bg-[#C94343] text-white font-body font-bold text-base shadow-md hover:bg-[#A92F35] active:scale-95 transition-all flex items-center gap-2 cursor-pointer hover:shadow-lg hover:shadow-[#C94343]/30"
        >
          <Sparkles className="w-4 h-4 text-amber-200" />
          <span>Celebrate Together! 🎉</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
};
