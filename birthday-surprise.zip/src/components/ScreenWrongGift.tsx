import React, { useState } from "react";
import { soundManager } from "../utils/audio";
import { RotateCcw, AlertTriangle } from "lucide-react";

interface ScreenWrongGiftProps {
  onTryAgain: () => void;
  shockedImage: string;
}

export const ScreenWrongGift: React.FC<ScreenWrongGiftProps> = ({ onTryAgain, shockedImage }) => {
  const [clickCount, setClickCount] = useState(0);

  const funnyCatchphrases = [
    "I said DO NOT TOUCH!! 😱",
    "Did you really think there was a 4th box?! 🧐",
    "Caught red-handed! 🙈",
    "The curiosity was too much, wasn't it?! 😂",
    "Okay, okay... forgive you! Go back and open the real gifts!",
  ];

  const handleTryAgain = () => {
    soundManager.playPop();
    onTryAgain();
  };

  return (
    <div className="w-full max-w-md mx-auto paper-card bg-[#FFFDF5] rounded-3xl p-6 sm:p-8 relative overflow-hidden border-2 border-red-400 shadow-2xl text-center animate-comic-shake">
      {/* Decorative Warning tape header */}
      <div className="w-full py-1.5 bg-red-600 text-white font-body font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2 rounded-lg mb-4 shadow-xs">
        <AlertTriangle className="w-4 h-4 text-amber-300" />
        <span>UNAUTHORIZED GIFT ACCESS</span>
        <AlertTriangle className="w-4 h-4 text-amber-300" />
      </div>

      {/* Exaggerated comic symbols floating */}
      <div className="absolute top-10 left-6 text-3xl font-bold text-red-500 font-handwriting rotate-[-15deg] animate-bounce">
        ❗❓
      </div>
      <div className="absolute top-12 right-6 text-3xl font-bold text-amber-500 font-handwriting rotate-[15deg] animate-pulse">
        💥
      </div>

      {/* Main Heading */}
      <h1 className="font-handwriting text-5xl sm:text-6xl font-black text-[#A92F35] tracking-wide mb-1 scale-105">
        HOW DARE YOU?
      </h1>
      <p className="font-handwriting text-xl text-stone-700 font-semibold mb-4">
        {funnyCatchphrases[clickCount % funnyCatchphrases.length]}
      </p>

      {/* Hilarious Shocked Cartoon Character */}
      <div className="relative my-3 flex justify-center">
        <div className="relative w-52 h-52 sm:w-60 sm:h-60 rounded-2xl overflow-hidden p-2 bg-white shadow-xl border-4 border-red-300 rotate-[-2deg]">
          <img
            src={shockedImage}
            alt="Shocked funny cartoon expression"
            className="w-full h-full object-cover rounded-xl"
            referrerPolicy="no-referrer"
          />

          {/* Comic sweat drop badge */}
          <div className="absolute top-2 right-2 px-2 py-0.5 bg-blue-100 text-blue-600 rounded text-xs font-bold font-body">
            SWEATING 💦
          </div>
        </div>
      </div>

      <p className="font-body text-xs text-stone-500 mt-2 mb-6">
        Curiosity is high, but the real surprises are waiting in the 3 main gift boxes! 😉
      </p>

      {/* TRY AGAIN BUTTON */}
      <div className="flex justify-center">
        <button
          onClick={handleTryAgain}
          className="group px-8 py-3.5 rounded-full bg-[#C94343] text-white font-body font-black text-lg shadow-lg hover:bg-[#A92F35] active:scale-95 transition-all flex items-center gap-2 cursor-pointer hover:shadow-red-500/40"
        >
          <RotateCcw className="w-5 h-5 group-hover:rotate-[-45deg] transition-transform" />
          <span>TRY AGAIN</span>
        </button>
      </div>
    </div>
  );
};
