import React, { useState } from "react";
import { soundManager } from "../utils/audio";
import { fireBirthdayConfetti, fireHeartConfetti } from "../utils/confetti";
import { Sparkles, Heart, ArrowRight, ArrowLeft, RotateCcw, AlertCircle } from "lucide-react";

interface ScreenGiftBoxesProps {
  onProceedToGallery: () => void;
  onTriggerWrongGift: () => void;
  gift1Title: string;
  gift1Message: string;
  gift2Title: string;
  gift2Message: string;
  gift2Photo: string;
  gift3Title: string;
  gift3Message: string;
  recipientName: string;
}

export const ScreenGiftBoxes: React.FC<ScreenGiftBoxesProps> = ({
  onProceedToGallery,
  onTriggerWrongGift,
  gift1Title,
  gift1Message,
  gift2Title,
  gift2Message,
  gift2Photo,
  gift3Title,
  gift3Message,
  recipientName,
}) => {
  const [openedGift, setOpenedGift] = useState<number | null>(null);
  const [openedHistory, setOpenedHistory] = useState<number[]>([]);

  const handleOpenGift = (giftNumber: number) => {
    soundManager.playUnwrap();
    setOpenedGift(giftNumber);
    if (!openedHistory.includes(giftNumber)) {
      setOpenedHistory((prev) => [...prev, giftNumber]);
    }

    if (giftNumber === 1) {
      fireBirthdayConfetti();
    } else if (giftNumber === 3) {
      fireHeartConfetti();
    }
  };

  const handleBackToGifts = () => {
    soundManager.playPop();
    setOpenedGift(null);
  };

  return (
    <div className="w-full max-w-4xl mx-auto paper-card bg-[#FFFDF5] rounded-3xl p-6 sm:p-8 md:p-10 relative overflow-hidden border border-[#C94343]/20 shadow-xl text-center">
      {/* Decorative dashed inner border */}
      <div className="absolute inset-3 border-2 border-dashed border-[#F8D9DC] rounded-2xl pointer-events-none" />

      {/* Header Section */}
      <div className="relative mb-6">
        <div className="inline-flex items-center gap-2 px-4 py-1 bg-[#FFE7DC] text-[#C94343] rounded-full border border-[#C94343]/20 shadow-xs mb-2">
          <Sparkles className="w-4 h-4 text-[#C94343]" />
          <span className="font-handwriting text-lg font-bold">Unwrap Your Presents</span>
          <Sparkles className="w-4 h-4 text-[#C94343]" />
        </div>

        <h1 className="font-handwriting text-3xl sm:text-4xl md:text-5xl font-bold text-[#A92F35]">
          Each gift has something for you.
        </h1>
        <p className="font-body text-xs sm:text-sm text-stone-500 mt-1 uppercase tracking-widest font-semibold">
          CLICK ON THE GIFTS
        </p>
      </div>

      {/* Main Container: Either 3 Gift Boxes OR the Opened Gift Detail View */}
      {openedGift === null ? (
        <div className="relative py-4">
          {/* Row of Three Distinct Gift Boxes */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 md:gap-8 items-center justify-center max-w-2xl mx-auto my-4">
            {/* GIFT BOX 1 */}
            <div
              onClick={() => handleOpenGift(1)}
              className="group cursor-pointer flex flex-col items-center animate-soft-float"
              style={{ animationDelay: "0s" }}
            >
              <div className="relative w-40 h-40 flex items-center justify-center transition-transform group-hover:scale-105 active:scale-95 duration-200">
                {/* Gift Bow on Top */}
                <div className="absolute top-2 z-20 flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-amber-300 border-2 border-amber-400 shadow-sm flex items-center justify-center text-xs">
                    🎀
                  </div>
                </div>

                {/* Gift Lid */}
                <div className="absolute top-6 w-36 h-8 bg-gradient-to-r from-[#F8D9DC] via-[#fbcfe8] to-[#F8D9DC] rounded-md shadow-md border border-rose-300 z-10 flex items-center justify-center">
                  <div className="w-5 h-full bg-[#C94343] shadow-xs" />
                </div>

                {/* Gift Box Body */}
                <div className="absolute top-12 w-32 h-28 bg-gradient-to-b from-[#C94343] to-[#A92F35] rounded-b-xl shadow-lg border border-red-800 flex items-center justify-center overflow-hidden">
                  {/* Vertical Ribbon */}
                  <div className="w-6 h-full bg-[#FFE7DC] shadow-xs" />
                  {/* Horizontal Ribbon */}
                  <div className="absolute w-full h-6 bg-[#FFE7DC] shadow-xs" />
                  {/* Gift Tag */}
                  <div className="absolute bottom-2 right-2 px-2 py-0.5 bg-white text-[#C94343] text-[10px] font-handwriting font-bold rounded shadow-xs rotate-[-6deg]">
                    No. 1 ✨
                  </div>
                </div>

                {/* Opened indicator badge */}
                {openedHistory.includes(1) && (
                  <div className="absolute -top-2 right-2 bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                    Opened ✓
                  </div>
                )}
              </div>

              <span className="font-handwriting text-xl text-[#A92F35] font-bold mt-2 group-hover:text-[#C94343] transition-colors">
                Gift #1
              </span>
              <span className="text-xs text-stone-500 font-body">Golden Wish</span>
            </div>

            {/* GIFT BOX 2 */}
            <div
              onClick={() => handleOpenGift(2)}
              className="group cursor-pointer flex flex-col items-center animate-soft-float"
              style={{ animationDelay: "0.8s" }}
            >
              <div className="relative w-40 h-40 flex items-center justify-center transition-transform group-hover:scale-105 active:scale-95 duration-200">
                {/* Gift Bow on Top */}
                <div className="absolute top-2 z-20 flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-[#FFE7DC] border-2 border-rose-300 shadow-sm flex items-center justify-center text-xs">
                    🎀
                  </div>
                </div>

                {/* Gift Lid */}
                <div className="absolute top-6 w-36 h-8 bg-gradient-to-r from-[#C94343] via-[#e15252] to-[#C94343] rounded-md shadow-md border border-red-800 z-10 flex items-center justify-center">
                  <div className="w-5 h-full bg-[#FFE7DC] shadow-xs" />
                </div>

                {/* Gift Box Body (Pink/Peach with Red Ribbon) */}
                <div className="absolute top-12 w-32 h-28 bg-gradient-to-b from-[#F8D9DC] to-[#f472b6]/70 rounded-b-xl shadow-lg border border-pink-300 flex items-center justify-center overflow-hidden">
                  {/* Vertical Ribbon */}
                  <div className="w-6 h-full bg-[#C94343] shadow-xs" />
                  {/* Horizontal Ribbon */}
                  <div className="absolute w-full h-6 bg-[#C94343] shadow-xs" />
                  {/* Gift Tag */}
                  <div className="absolute bottom-2 right-2 px-2 py-0.5 bg-white text-[#C94343] text-[10px] font-handwriting font-bold rounded shadow-xs rotate-4">
                    No. 2 📸
                  </div>
                </div>

                {/* Opened indicator badge */}
                {openedHistory.includes(2) && (
                  <div className="absolute -top-2 right-2 bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                    Opened ✓
                  </div>
                )}
              </div>

              <span className="font-handwriting text-xl text-[#A92F35] font-bold mt-2 group-hover:text-[#C94343] transition-colors">
                Gift #2
              </span>
              <span className="text-xs text-stone-500 font-body">Photo Memory</span>
            </div>

            {/* GIFT BOX 3 */}
            <div
              onClick={() => handleOpenGift(3)}
              className="group cursor-pointer flex flex-col items-center animate-soft-float"
              style={{ animationDelay: "1.6s" }}
            >
              <div className="relative w-40 h-40 flex items-center justify-center transition-transform group-hover:scale-105 active:scale-95 duration-200">
                {/* Gift Bow on Top */}
                <div className="absolute top-2 z-20 flex flex-col items-center">
                  <div className="w-8 h-8 rounded-full bg-rose-400 border-2 border-rose-500 shadow-sm flex items-center justify-center text-xs">
                    💖
                  </div>
                </div>

                {/* Gift Lid */}
                <div className="absolute top-6 w-36 h-8 bg-gradient-to-r from-[#FFE7DC] via-[#fed7aa] to-[#FFE7DC] rounded-md shadow-md border border-amber-300 z-10 flex items-center justify-center">
                  <div className="w-5 h-full bg-[#C94343] shadow-xs" />
                </div>

                {/* Gift Box Body (Burgundy Red with Gold/Peach Ribbon) */}
                <div className="absolute top-12 w-32 h-28 bg-gradient-to-b from-[#A92F35] to-[#7f1d1d] rounded-b-xl shadow-lg border border-red-950 flex items-center justify-center overflow-hidden">
                  {/* Vertical Ribbon */}
                  <div className="w-6 h-full bg-amber-200 shadow-xs" />
                  {/* Horizontal Ribbon */}
                  <div className="absolute w-full h-6 bg-amber-200 shadow-xs" />
                  {/* Gift Tag */}
                  <div className="absolute bottom-2 right-2 px-2 py-0.5 bg-white text-[#C94343] text-[10px] font-handwriting font-bold rounded shadow-xs rotate-[-3deg]">
                    No. 3 💌
                  </div>
                </div>

                {/* Opened indicator badge */}
                {openedHistory.includes(3) && (
                  <div className="absolute -top-2 right-2 bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs">
                    Opened ✓
                  </div>
                )}
              </div>

              <span className="font-handwriting text-xl text-[#A92F35] font-bold mt-2 group-hover:text-[#C94343] transition-colors">
                Gift #3
              </span>
              <span className="text-xs text-stone-500 font-body">Secret Note</span>
            </div>
          </div>

          {/* Special Secret "Do Not Touch" / Mystery Mystery Box (triggers Screen 5) */}
          <div className="mt-6 pt-4 border-t border-[#F8D9DC] flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => {
                soundManager.playBuzzer();
                onTriggerWrongGift();
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-body font-semibold rounded-full border border-rose-200 shadow-2xs transition-colors cursor-pointer"
            >
              <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
              <span>Secret 4th Gift (DO NOT CLICK! 🤫)</span>
            </button>

            <button
              onClick={() => {
                soundManager.playChime();
                onProceedToGallery();
              }}
              className="inline-flex items-center gap-2 px-6 py-2.5 bg-[#C94343] text-white text-sm font-body font-bold rounded-full shadow-md hover:bg-[#A92F35] active:scale-95 transition-all cursor-pointer"
            >
              <span>View Memory Gallery</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        /* OPENED GIFT MODAL / REVEAL VIEW */
        <div className="relative py-4 max-w-xl mx-auto animate-fade-in">
          {/* GIFT 1 CONTENT */}
          {openedGift === 1 && (
            <div className="bg-[#FFF9F9] rounded-2xl p-6 sm:p-8 border border-rose-200 shadow-md text-center relative overflow-hidden">
              <div className="w-16 h-16 mx-auto mb-3 bg-amber-100 rounded-full flex items-center justify-center text-3xl shadow-xs">
                🎁
              </div>
              <h2 className="font-handwriting text-3xl sm:text-4xl font-bold text-[#A92F35] mb-2">
                {gift1Title}
              </h2>
              <p className="font-handwriting text-xl sm:text-2xl text-stone-700 leading-relaxed max-w-md mx-auto my-4">
                {gift1Message}
              </p>
              <div className="flex justify-center gap-2 my-2 text-rose-500">
                <span>✨</span>
                <span>💖</span>
                <span>🎂</span>
                <span>💖</span>
                <span>✨</span>
              </div>
            </div>
          )}

          {/* GIFT 2 CONTENT */}
          {openedGift === 2 && (
            <div className="bg-[#FFF9F9] rounded-2xl p-6 sm:p-8 border border-rose-200 shadow-md text-center relative overflow-hidden">
              <div className="w-16 h-16 mx-auto mb-3 bg-rose-100 rounded-full flex items-center justify-center text-3xl shadow-xs">
                📸
              </div>
              <h2 className="font-handwriting text-3xl sm:text-4xl font-bold text-[#A92F35] mb-2">
                {gift2Title}
              </h2>

              {/* Reveal Polaroid Photo */}
              <div className="max-w-[260px] mx-auto bg-white p-3 pb-6 rounded-lg shadow-md border border-stone-200 rotate-[-1deg] my-3">
                <div className="aspect-4/3 w-full rounded overflow-hidden">
                  <img
                    src={gift2Photo}
                    alt="Memory gift"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <p className="font-handwriting text-lg text-stone-700 font-bold mt-2">
                  Best Times Ever ✨
                </p>
              </div>

              <p className="font-handwriting text-xl sm:text-2xl text-stone-700 leading-relaxed max-w-md mx-auto my-3">
                {gift2Message}
              </p>
            </div>
          )}

          {/* GIFT 3 CONTENT */}
          {openedGift === 3 && (
            <div className="bg-[#FFF9F9] rounded-2xl p-6 sm:p-8 border border-rose-200 shadow-md text-center relative overflow-hidden">
              {/* Animated Blooming Heart */}
              <div className="relative w-20 h-20 mx-auto mb-3 flex items-center justify-center">
                <div className="absolute inset-0 bg-rose-200 rounded-full animate-ping opacity-30" />
                <div className="w-16 h-16 bg-gradient-to-tr from-[#C94343] to-rose-400 rounded-full flex items-center justify-center text-white text-3xl shadow-md">
                  <Heart className="w-8 h-8 fill-white" />
                </div>
              </div>

              <h2 className="font-handwriting text-3xl sm:text-4xl font-bold text-[#A92F35] mb-2">
                {gift3Title}
              </h2>
              <p className="font-handwriting text-xl sm:text-2xl text-stone-700 leading-relaxed max-w-md mx-auto my-4">
                {gift3Message}
              </p>
              <div className="inline-block px-4 py-1.5 bg-[#FFE7DC] text-[#A92F35] font-handwriting text-lg rounded-full font-bold">
                Always here for you, {recipientName} 💕
              </div>
            </div>
          )}

          {/* Controls after opening gift */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-6">
            <button
              onClick={handleBackToGifts}
              className="px-6 py-2.5 rounded-full bg-stone-100 hover:bg-stone-200 text-stone-700 font-body font-semibold text-sm border border-stone-300 shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Back to Gift Boxes</span>
            </button>

            <button
              onClick={() => {
                soundManager.playChime();
                onProceedToGallery();
              }}
              className="px-6 py-2.5 rounded-full bg-[#C94343] text-white font-body font-bold text-sm shadow-md hover:bg-[#A92F35] transition-all flex items-center gap-2 cursor-pointer"
            >
              <span>See All Memories</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
