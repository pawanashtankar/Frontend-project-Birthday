import React, { useState, useRef } from "react";
import { soundManager } from "../utils/audio";
import { fireHeartConfetti } from "../utils/confetti";
import { Sparkles, Heart } from "lucide-react";

interface ScreenIntroProps {
  onYes: () => void;
  introImage: string;
}

export const ScreenIntro: React.FC<ScreenIntroProps> = ({ onYes, introImage }) => {
  const [noAttempts, setNoAttempts] = useState(0);
  const [noOffset, setNoOffset] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const funnyNoMessages = [
    "No",
    "Are you sure? 🥺",
    "Please say YES! 💕",
    "You don't want your surprise?! 🎁",
    "Look how cute this is! 🥺",
    "Think about it again! ✨",
    "There's cake inside! 🎂",
    "Pretty please say YES! 💖",
    "You cannot resist! 🙈",
  ];

  const handleNoInteraction = () => {
    soundManager.playPop();
    setNoAttempts((prev) => prev + 1);

    // Playful offset within reasonable card boundaries
    const maxDistance = 75;
    const randomAngle = Math.random() * Math.PI * 2;
    const distance = 40 + Math.random() * maxDistance;
    const newX = Math.cos(randomAngle) * distance;
    const newY = Math.sin(randomAngle) * distance;

    setNoOffset({
      x: Math.max(-120, Math.min(120, newX)),
      y: Math.max(-60, Math.min(60, newY)),
    });
  };

  const handleYesClick = () => {
    soundManager.playChime();
    fireHeartConfetti();
    onYes();
  };

  const currentNoText = funnyNoMessages[Math.min(noAttempts, funnyNoMessages.length - 1)];

  return (
    <div
      ref={containerRef}
      className="w-full max-w-md mx-auto paper-card bg-[#FFFDF5] rounded-3xl p-6 md:p-8 relative overflow-hidden border border-[#C94343]/20 text-center transition-all duration-300"
    >
      {/* Decorative inner stamp border */}
      <div className="absolute inset-2 border-2 border-dashed border-[#F8D9DC] rounded-2xl pointer-events-none" />

      {/* Decorative header ribbon sticker */}
      <div className="relative inline-flex items-center justify-center gap-1.5 px-4 py-1 bg-[#FFE7DC] text-[#C94343] font-handwriting text-lg md:text-xl rounded-full mb-3 shadow-xs border border-[#C94343]/15">
        <Sparkles className="w-4 h-4 text-[#C94343]" />
        <span>Surprise for you</span>
        <Sparkles className="w-4 h-4 text-[#C94343]" />
      </div>

      {/* Main Handwritten Heading */}
      <h1 className="font-handwriting text-3xl sm:text-4xl md:text-5xl font-bold text-[#A92F35] leading-tight mb-2">
        I have made something for you!
      </h1>

      {/* Cute Cartoon Illustration */}
      <div className="relative my-4 flex justify-center items-center">
        <div className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-2xl overflow-hidden p-2 bg-white shadow-md border-2 border-[#F8D9DC] rotate-[-1deg] transition-transform hover:rotate-1 duration-300">
          <img
            src={introImage}
            alt="Cute cartoon character with a birthday surprise"
            className="w-full h-full object-cover rounded-xl"
            referrerPolicy="no-referrer"
          />
          {/* Cute tape sticker in top corner */}
          <div className="absolute top-1 left-1/2 -translate-x-1/2 w-14 h-4 bg-[#F8D9DC]/80 backdrop-blur-xs rounded-xs border border-white/60 rotate-2 shadow-xs" />
        </div>

        {/* Floating Heart stickers */}
        <div className="absolute -top-1 right-8 text-rose-500 animate-bounce">
          <Heart className="w-6 h-6 fill-[#C94343] text-[#C94343]" />
        </div>
        <div className="absolute bottom-2 left-6 text-amber-400 animate-pulse">
          <Sparkles className="w-5 h-5 text-amber-400" />
        </div>
      </div>

      {/* Sub-question */}
      <p className="font-handwriting text-2xl sm:text-3xl text-stone-700 font-semibold mb-6">
        Do you wanna see it?
      </p>

      {/* Interactive Action Buttons */}
      <div className="relative flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 min-h-[90px] pt-2">
        {/* YES BUTTON */}
        <button
          onClick={handleYesClick}
          className="group relative z-10 px-8 py-3 rounded-full bg-[#C94343] text-white font-body font-bold text-base sm:text-lg shadow-md hover:bg-[#A92F35] active:scale-95 transition-all duration-200 cursor-pointer flex items-center gap-2 hover:shadow-lg hover:shadow-[#C94343]/30 min-w-[130px] justify-center"
        >
          <span>YES!</span>
          <Heart className="w-4 h-4 fill-white text-white group-hover:scale-125 transition-transform" />
        </button>

        {/* NO BUTTON (Playfully moves away or dances) */}
        <div
          style={{
            transform: `translate(${noOffset.x}px, ${noOffset.y}px)`,
            transition: "transform 0.22s cubic-bezier(0.34, 1.56, 0.64, 1)",
          }}
          className="relative inline-block z-20"
        >
          <button
            onClick={handleNoInteraction}
            onMouseEnter={handleNoInteraction}
            onTouchStart={handleNoInteraction}
            className="px-6 py-3 rounded-full bg-stone-100 text-stone-600 font-body font-medium text-sm sm:text-base border border-stone-300 shadow-xs hover:bg-stone-200 active:scale-90 transition-colors cursor-pointer whitespace-nowrap"
          >
            {currentNoText}
          </button>
        </div>
      </div>

      {noAttempts > 0 && (
        <p className="mt-3 font-handwriting text-base text-[#C94343] italic animate-fade-in">
          {noAttempts >= 3 ? "There is no escape from your birthday surprise! 💖" : "Hehe, you can't click no!"}
        </p>
      )}
    </div>
  );
};
