import React from "react";

export const DecorativeBackground: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="relative min-h-screen bg-[#FFFDF5] text-stone-800 flex flex-col justify-between overflow-x-hidden">
      {/* Left Gingham Border (Stationery edge) */}
      <div
        className="fixed top-0 bottom-0 left-0 w-3 md:w-6 lg:w-8 gingham-pattern z-10 border-r border-[#C94343]/20 shadow-xs pointer-events-none"
        aria-hidden="true"
      />

      {/* Right Gingham Border (Stationery edge) */}
      <div
        className="fixed top-0 bottom-0 right-0 w-3 md:w-6 lg:w-8 gingham-pattern z-10 border-l border-[#C94343]/20 shadow-xs pointer-events-none"
        aria-hidden="true"
      />

      {/* Subtle Floating Sparkles and Little Hearts in background */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden opacity-40 select-none">
        <span className="absolute top-[12%] left-[10%] text-xl text-rose-300 animate-soft-float">✦</span>
        <span className="absolute top-[28%] right-[14%] text-lg text-amber-300 animate-soft-float" style={{ animationDelay: "1s" }}>✨</span>
        <span className="absolute top-[45%] left-[8%] text-base text-rose-400 animate-soft-float" style={{ animationDelay: "1.5s" }}>♥</span>
        <span className="absolute top-[68%] right-[10%] text-xl text-rose-300 animate-soft-float" style={{ animationDelay: "2s" }}>✦</span>
        <span className="absolute top-[82%] left-[12%] text-sm text-amber-400 animate-soft-float" style={{ animationDelay: "0.5s" }}>✨</span>
        <span className="absolute top-[88%] right-[16%] text-base text-rose-400 animate-soft-float" style={{ animationDelay: "2.5s" }}>♥</span>
      </div>

      {/* Main Content Area */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 md:px-10 py-6 md:py-10">
        {children}
      </main>

      {/* Sweet subtle footer tag */}
      <footer className="relative z-10 text-center py-3 text-stone-400 text-xs font-handwriting tracking-wide pointer-events-none">
        Made with love & celebration ✨
      </footer>
    </div>
  );
};
