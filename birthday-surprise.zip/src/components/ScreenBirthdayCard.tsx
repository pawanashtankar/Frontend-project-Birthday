import React from "react";
import { soundManager } from "../utils/audio";
import { fireHeartConfetti } from "../utils/confetti";
import { Sparkles, Heart, Gift, ArrowRight } from "lucide-react";

interface ScreenBirthdayCardProps {
  onContinue: () => void;
  recipientName: string;
  recipientPhoto: string;
  birthdayMessage: string;
  cartoonImage: string;
}

export const ScreenBirthdayCard: React.FC<ScreenBirthdayCardProps> = ({
  onContinue,
  recipientName,
  recipientPhoto,
  birthdayMessage,
  cartoonImage,
}) => {
  return (
    <div className="w-full max-w-2xl mx-auto paper-card bg-[#FFFDF5] rounded-3xl p-6 sm:p-8 md:p-10 relative overflow-hidden border border-[#C94343]/20 shadow-xl transition-all duration-300">
      {/* Decorative Outer Gingham Ribbon Accent */}
      <div className="absolute top-0 left-0 right-0 h-3 gingham-pattern border-b border-[#C94343]/25" />
      <div className="absolute bottom-0 left-0 right-0 h-3 gingham-pattern border-t border-[#C94343]/25" />

      {/* Decorative dashed card border */}
      <div className="absolute inset-4 border-2 border-dashed border-[#F8D9DC] rounded-2xl pointer-events-none" />

      {/* Ribbon Banner Header */}
      <div className="relative text-center mb-6">
        <div className="inline-flex items-center gap-2 px-5 py-1.5 bg-[#FFE7DC] text-[#C94343] rounded-full border border-[#C94343]/20 shadow-xs">
          <Sparkles className="w-4 h-4 text-[#C94343]" />
          <span className="font-handwriting text-lg sm:text-xl font-bold tracking-wider">
            ★ Special Day Edition ★
          </span>
          <Sparkles className="w-4 h-4 text-[#C94343]" />
        </div>

        <h1 className="font-cursive text-5xl sm:text-6xl md:text-7xl font-bold text-[#A92F35] mt-2 mb-1 drop-shadow-xs">
          HAPPY Birthday
        </h1>
        <p className="font-handwriting text-2xl sm:text-3xl text-[#C94343] font-bold">
          To the wonderful {recipientName}!
        </p>
      </div>

      {/* Card Body with Split Layout: Message on Left, Photo Polaroid on Right */}
      <div className="relative grid grid-cols-1 md:grid-cols-12 gap-6 items-center my-4">
        {/* Left Side: Heartfelt greeting message */}
        <div className="md:col-span-7 text-left space-y-4 pr-0 md:pr-2">
          <div className="bg-[#FFF9F9] p-4 sm:p-5 rounded-2xl border border-rose-100 shadow-xs relative">
            <span className="font-cursive text-3xl text-[#C94343] block -mb-1">“</span>
            <p className="font-handwriting text-xl sm:text-2xl text-stone-700 leading-relaxed">
              {birthdayMessage}
            </p>
            <span className="font-cursive text-3xl text-[#C94343] block text-right -mt-2">”</span>

            {/* Little decorative hearts */}
            <div className="absolute -top-2 right-4 flex gap-1">
              <span className="text-sm">💖</span>
              <span className="text-xs">✨</span>
            </div>
          </div>

          {/* Cute cartoon illustration sticker */}
          <div className="flex items-center gap-3 pt-1">
            <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-[#C94343]/30 p-0.5 bg-white shadow-xs shrink-0">
              <img
                src={cartoonImage}
                alt="Birthday mascot"
                className="w-full h-full object-cover rounded-full"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <p className="font-handwriting text-base sm:text-lg text-[#A92F35] font-bold">
                Sending warm hugs & smiles!
              </p>
              <p className="text-xs text-stone-500 font-body">May this year be your happiest yet.</p>
            </div>
          </div>
        </div>

        {/* Right Side: Recipient Polaroid Frame */}
        <div className="md:col-span-5 flex justify-center">
          <div className="relative bg-white p-3 pb-8 rounded-lg shadow-lg border border-stone-200 rotate-2 hover:rotate-0 transition-transform duration-300 max-w-[240px]">
            {/* Washi Tape at Top */}
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-20 h-5 bg-[#F8D9DC]/90 backdrop-blur-xs border border-white/80 rounded-xs rotate-[-3deg] shadow-xs z-10" />

            {/* Photo Container */}
            <div className="relative aspect-square w-full rounded-md overflow-hidden bg-stone-100 border border-stone-100">
              <img
                src={recipientPhoto}
                alt={`Happy Birthday ${recipientName}`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-2 right-2 px-2 py-0.5 bg-black/40 backdrop-blur-xs text-white text-[10px] rounded-full font-body">
                Birthday Star ✨
              </div>
            </div>

            {/* Polaroid Handwritten Caption */}
            <div className="mt-3 text-center">
              <p className="font-handwriting text-lg text-stone-800 font-bold tracking-wide">
                {recipientName} 💕
              </p>
              <p className="text-[10px] text-stone-400 font-body uppercase tracking-wider">
                Forever Shining
              </p>
            </div>

            {/* Little Corner Bow Stamp */}
            <div className="absolute -bottom-2 -left-2 text-rose-500 text-lg">
              🎀
            </div>
          </div>
        </div>
      </div>

      {/* Decorative Ribbon Name Banner at the Bottom */}
      <div className="relative mt-6 pt-4 border-t border-rose-100 text-center">
        <div className="inline-flex items-center gap-3 px-6 py-2 bg-gradient-to-r from-[#C94343] to-[#A92F35] text-white rounded-full shadow-md">
          <Heart className="w-4 h-4 fill-white" />
          <span className="font-handwriting text-xl sm:text-2xl font-bold tracking-wide">
            Happy Birthday, {recipientName}!
          </span>
          <Heart className="w-4 h-4 fill-white" />
        </div>
      </div>

      {/* Continue Button */}
      <div className="flex justify-center mt-6">
        <button
          onClick={() => {
            soundManager.playChime();
            fireHeartConfetti();
            onContinue();
          }}
          className="group px-8 py-3 rounded-full bg-[#C94343] text-white font-body font-bold text-base shadow-md hover:bg-[#A92F35] active:scale-95 transition-all flex items-center gap-2 cursor-pointer hover:shadow-lg hover:shadow-[#C94343]/30"
        >
          <Gift className="w-4 h-4 text-rose-200" />
          <span>See Your Birthday Gifts</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
};
