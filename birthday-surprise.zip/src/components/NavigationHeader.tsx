import React from "react";
import { Music, VolumeX, Sparkles, SlidersHorizontal, RotateCcw } from "lucide-react";
import { soundManager } from "../utils/audio";

interface NavigationHeaderProps {
  currentScreen: number;
  totalScreens: number;
  onSelectScreen: (screen: number) => void;
  onOpenCustomize: () => void;
  onRestart: () => void;
  isMusicPlaying: boolean;
  setIsMusicPlaying: (playing: boolean) => void;
}

export const NavigationHeader: React.FC<NavigationHeaderProps> = ({
  currentScreen,
  totalScreens,
  onSelectScreen,
  onOpenCustomize,
  onRestart,
  isMusicPlaying,
  setIsMusicPlaying,
}) => {
  const toggleMusic = () => {
    const nextState = soundManager.toggleMusic();
    setIsMusicPlaying(nextState);
  };

  const stepTitles = [
    "Surprise",
    "Make a Wish",
    "Birthday Card",
    "Gift Boxes",
    "Surprise!",
    "Memories",
    "Letter",
    "Celebration",
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#FFFDF5]/90 backdrop-blur-md border-b border-[#C94343]/15 px-4 md:px-8 py-3 transition-colors">
      <div className="max-w-5xl mx-auto flex items-center justify-between gap-4">
        {/* Zone 1: Wordmark */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onSelectScreen(1)}
            className="flex items-center gap-1.5 text-base md:text-lg font-bold font-handwriting text-[#C94343] hover:opacity-80 transition-opacity"
          >
            <Sparkles className="w-5 h-5 text-[#C94343]" />
            <span className="tracking-wide">Birthday Surprise</span>
          </button>
        </div>

        {/* Zone 2: Step Indicator / Story chapter */}
        <div className="hidden sm:flex items-center gap-1.5 bg-[#FFE7DC]/60 px-3 py-1.5 rounded-full border border-[#C94343]/20">
          <span className="text-xs font-semibold text-[#A92F35] font-body tracking-wider uppercase">
            {stepTitles[currentScreen - 1] || "Story"}
          </span>
          <span className="text-[#C94343]/40 text-xs">·</span>
          <div className="flex items-center gap-1">
            {Array.from({ length: totalScreens }).map((_, i) => {
              const stepNum = i + 1;
              const isActive = stepNum === currentScreen;
              const isPast = stepNum < currentScreen;
              return (
                <button
                  key={stepNum}
                  onClick={() => {
                    soundManager.playPop();
                    onSelectScreen(stepNum);
                  }}
                  title={`Go to ${stepTitles[i]}`}
                  className={`w-2.5 h-2.5 rounded-full transition-all duration-200 ${
                    isActive
                      ? "bg-[#C94343] scale-125 ring-2 ring-[#C94343]/30"
                      : isPast
                      ? "bg-[#F8D9DC] hover:bg-[#C94343]/60"
                      : "bg-stone-200 hover:bg-stone-300"
                  }`}
                  aria-label={`Jump to page ${stepNum}`}
                />
              );
            })}
          </div>
        </div>

        {/* Zone 3: Actions (Music toggle + Customize + Restart) */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleMusic}
            title={isMusicPlaying ? "Mute Birthday Music" : "Play Birthday Music"}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium font-body transition-all duration-200 shadow-xs border ${
              isMusicPlaying
                ? "bg-[#C94343] text-white border-[#A92F35] hover:bg-[#A92F35] animate-pulse"
                : "bg-white text-stone-700 border-stone-200 hover:bg-stone-50"
            }`}
          >
            {isMusicPlaying ? (
              <>
                <Music className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">Music ON</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5 text-stone-500" />
                <span className="hidden xs:inline">Music OFF</span>
              </>
            )}
          </button>

          <button
            onClick={() => {
              soundManager.playPop();
              onOpenCustomize();
            }}
            title="Personalize Names & Messages"
            className="p-2 rounded-full text-stone-700 bg-white hover:bg-[#FFE7DC] border border-stone-200 transition-colors"
            aria-label="Customize card details"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#C94343]" />
          </button>

          <button
            onClick={() => {
              soundManager.playPop();
              onRestart();
            }}
            title="Restart Experience"
            className="p-2 rounded-full text-stone-700 bg-white hover:bg-[#FFE7DC] border border-stone-200 transition-colors"
            aria-label="Restart from beginning"
          >
            <RotateCcw className="w-3.5 h-3.5 text-stone-600" />
          </button>
        </div>
      </div>
    </header>
  );
};
