/**
 * Centralized Configuration for Birthday Surprise Experience
 * Easily customize recipient name, messages, photos, and gifts here!
 */

export interface MemoryPhoto {
  id: string;
  url: string;
  caption: string;
  date?: string;
  rotation: number;
}

export interface BirthdayConfig {
  RECIPIENT_NAME: string;
  YOUR_NAME: string;
  RECIPIENT_PHOTO: string;
  INTRO_CARTOON: string;
  SHOCKED_CARTOON: string;
  BIRTHDAY_MESSAGE: string;
  GIFT_1_TITLE: string;
  GIFT_1_MESSAGE: string;
  GIFT_2_TITLE: string;
  GIFT_2_MESSAGE: string;
  GIFT_2_PHOTO: string;
  GIFT_3_TITLE: string;
  GIFT_3_MESSAGE: string;
  LETTER_TITLE: string;
  LETTER_PARAGRAPHS: string[];
  MEMORY_PHOTOS: MemoryPhoto[];
}

export const initialBirthdayConfig: BirthdayConfig = {
  RECIPIENT_NAME: "Emma",
  YOUR_NAME: "Lucas",
  RECIPIENT_PHOTO: "/src/assets/images/recipient_portrait_1794164350839.jpg",
  INTRO_CARTOON: "/src/assets/images/intro_cartoon_boy_1794164349515.jpg",
  SHOCKED_CARTOON: "/src/assets/images/shocked_cartoon_character_1794164350756.jpg",
  BIRTHDAY_MESSAGE: "Today is your special day. I hope your day is filled with happiness, laughter, beautiful memories, and everything your heart wishes for.",
  
  GIFT_1_TITLE: "A Golden Wish ✨",
  GIFT_1_MESSAGE: "Surprise! 🎉 You are the brightest light in every room you walk into. May your next year be overflowing with unexpected wonders, late-night belly laughs, and dreams turning into reality!",
  
  GIFT_2_TITLE: "A Favorite Memory 📸",
  GIFT_2_MESSAGE: "Look at how much joy we've shared together! From silly spontaneous adventures to cozy hours of conversation, having you by my side makes life magical.",
  GIFT_2_PHOTO: "/src/assets/images/memory_photo_celebration_1794164351613.jpg",
  
  GIFT_3_TITLE: "A Secret From the Heart 💌",
  GIFT_3_MESSAGE: "You are truly one of a kind. Thank you for always bringing warmth and comfort wherever you go. Never forget how loved and cherished you are!",

  LETTER_TITLE: "My fav person",
  LETTER_PARAGRAPHS: [
    "Happy Birthday, Emma!",
    "I honestly don't know how to put into words how much you mean to me.",
    "Thank you for being there, for making memories, for bringing happiness, and for being such a special part of my life.",
    "I hope your birthday is filled with endless smiles, beautiful moments, and everything you have ever wished for.",
    "You deserve all the happiness in the world.",
    "Thank you for being YOU.",
    "Have the happiest birthday ever!",
  ],

  MEMORY_PHOTOS: [
    {
      id: "mem-1",
      url: "/src/assets/images/memory_photo_celebration_1794164351613.jpg",
      caption: "Midnight cupcakes, sparklers & uncontrollable laughter ✨",
      date: "October 14",
      rotation: -3,
    },
    {
      id: "mem-2",
      url: "/src/assets/images/memory_photo_travel_1794164351625.jpg",
      caption: "Golden hour walks through summer wildflower trails 🌸",
      date: "July 22",
      rotation: 2.5,
    },
    {
      id: "mem-3",
      url: "/src/assets/images/memory_photo_sunset_1794164368916.jpg",
      caption: "Sunset terrace conversations overlooking the city 🍷",
      date: "September 05",
      rotation: -2,
    },
    {
      id: "mem-4",
      url: "/src/assets/images/memory_photo_picnic_1794164369489.jpg",
      caption: "Cozy strawberry cake picnic in the sunshine 🍓",
      date: "May 18",
      rotation: 3.5,
    },
  ],
};
