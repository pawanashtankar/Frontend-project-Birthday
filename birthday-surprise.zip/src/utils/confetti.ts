import confetti from "canvas-confetti";

export function fireBirthdayConfetti() {
  // Burst from left and right
  const count = 200;
  const defaults = {
    origin: { y: 0.7 },
    colors: ["#C94343", "#F8D9DC", "#FFE7DC", "#F59E0B", "#EF4444", "#FFFFFF"],
  };

  confetti({
    ...defaults,
    particleCount: Math.floor(count * 0.25),
    spread: 26,
    startVelocity: 55,
  });

  confetti({
    ...defaults,
    particleCount: Math.floor(count * 0.2),
    spread: 60,
  });

  confetti({
    ...defaults,
    particleCount: Math.floor(count * 0.35),
    spread: 100,
    decay: 0.91,
    scalar: 0.8,
  });

  confetti({
    ...defaults,
    particleCount: Math.floor(count * 0.1),
    spread: 120,
    startVelocity: 25,
    decay: 0.92,
    scalar: 1.2,
  });
}

export function fireHeartConfetti() {
  const scalar = 2;
  const heart = confetti.shapeFromText({ text: "❤️", scalar });
  const star = confetti.shapeFromText({ text: "✨", scalar });

  confetti({
    shapes: [heart, star],
    particleCount: 25,
    spread: 80,
    origin: { y: 0.6 },
  });
}
