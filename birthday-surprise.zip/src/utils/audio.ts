/**
 * Web Audio API synthesizer for music box "Happy Birthday" melody and cute sound effects.
 * 100% client-side, zero external audio dependency failures.
 */

class SoundController {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private isMusicPlaying: boolean = false;
  private musicTimeout: number | null = null;
  private noteIndex: number = 0;

  // Happy Birthday melody notes (frequency, duration in seconds, pause after)
  private melody = [
    { freq: 392.00, dur: 0.35, pause: 0.1 }, // G4
    { freq: 392.00, dur: 0.35, pause: 0.1 }, // G4
    { freq: 440.00, dur: 0.6, pause: 0.1 },  // A4
    { freq: 392.00, dur: 0.6, pause: 0.1 },  // G4
    { freq: 523.25, dur: 0.6, pause: 0.1 },  // C5
    { freq: 493.88, dur: 1.1, pause: 0.25 }, // B4

    { freq: 392.00, dur: 0.35, pause: 0.1 }, // G4
    { freq: 392.00, dur: 0.35, pause: 0.1 }, // G4
    { freq: 440.00, dur: 0.6, pause: 0.1 },  // A4
    { freq: 392.00, dur: 0.6, pause: 0.1 },  // G4
    { freq: 587.33, dur: 0.6, pause: 0.1 },  // D5
    { freq: 523.25, dur: 1.1, pause: 0.25 }, // C5

    { freq: 392.00, dur: 0.35, pause: 0.1 }, // G4
    { freq: 392.00, dur: 0.35, pause: 0.1 }, // G4
    { freq: 783.99, dur: 0.6, pause: 0.1 },  // G5
    { freq: 659.25, dur: 0.6, pause: 0.1 },  // E5
    { freq: 523.25, dur: 0.6, pause: 0.1 },  // C5
    { freq: 493.88, dur: 0.6, pause: 0.1 },  // B4
    { freq: 440.00, dur: 0.9, pause: 0.25 }, // A4

    { freq: 698.46, dur: 0.35, pause: 0.1 }, // F5
    { freq: 698.46, dur: 0.35, pause: 0.1 }, // F5
    { freq: 659.25, dur: 0.6, pause: 0.1 },  // E5
    { freq: 523.25, dur: 0.6, pause: 0.1 },  // C5
    { freq: 587.33, dur: 0.6, pause: 0.1 },  // D5
    { freq: 523.25, dur: 1.4, pause: 0.8 },  // C5
  ];

  private getContext(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  // Play a music box tone
  private playBellTone(freq: number, duration: number, gainMultiplier = 1) {
    const ctx = this.getContext();
    if (!ctx || this.isMuted) return;

    try {
      const osc = ctx.createOscillator();
      const oscHarmonic = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime);

      // Add soft celestial octave shimmer
      oscHarmonic.type = "triangle";
      oscHarmonic.frequency.setValueAtTime(freq * 2, ctx.currentTime);

      const now = ctx.currentTime;
      const attack = 0.015;
      const peakGain = 0.12 * gainMultiplier;

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(peakGain, now + attack);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

      osc.connect(gain);
      oscHarmonic.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      oscHarmonic.start(now);

      osc.stop(now + duration + 0.1);
      oscHarmonic.stop(now + duration + 0.1);
    } catch {
      // Audio error silently handled
    }
  }

  // Music playback loop
  public startMusic() {
    this.isMusicPlaying = true;
    this.scheduleNextNote();
  }

  public stopMusic() {
    this.isMusicPlaying = false;
    if (this.musicTimeout !== null) {
      clearTimeout(this.musicTimeout);
      this.musicTimeout = null;
    }
    this.noteIndex = 0;
  }

  public toggleMusic(): boolean {
    if (this.isMusicPlaying) {
      this.stopMusic();
      return false;
    } else {
      this.startMusic();
      return true;
    }
  }

  public isPlaying(): boolean {
    return this.isMusicPlaying;
  }

  private scheduleNextNote = () => {
    if (!this.isMusicPlaying) return;

    const note = this.melody[this.noteIndex];
    if (note) {
      this.playBellTone(note.freq, note.dur, 0.9);
      const totalDelay = (note.dur + note.pause) * 1000;
      this.noteIndex = (this.noteIndex + 1) % this.melody.length;
      this.musicTimeout = window.setTimeout(this.scheduleNextNote, totalDelay);
    }
  };

  // Sound Effects

  // Cute bubble / button pop
  public playPop() {
    const ctx = this.getContext();
    if (!ctx || this.isMuted) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const now = ctx.currentTime;

      osc.type = "sine";
      osc.frequency.setValueAtTime(450, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.08);

      gain.gain.setValueAtTime(0.18, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.1);
    } catch {
      // Ignore audio context exceptions
    }
  }

  // Chime arpeggio for celebration / next page
  public playChime() {
    const freqs = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    freqs.forEach((freq, idx) => {
      setTimeout(() => {
        this.playBellTone(freq, 0.45, 0.7);
      }, idx * 75);
    });
  }

  // Gift unwrap magic burst
  public playUnwrap() {
    const notes = [440, 554.37, 659.25, 880, 1108.73, 1318.51];
    notes.forEach((freq, idx) => {
      setTimeout(() => {
        this.playBellTone(freq, 0.5, 0.8);
      }, idx * 60);
    });
  }

  // Candle blow out sound (gentle wind breath + sparkle)
  public playBlowOut() {
    const ctx = this.getContext();
    if (!ctx || this.isMuted) return;

    try {
      // White noise buffer for gentle puff
      const bufferSize = ctx.sampleRate * 0.4;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * 0.3;
      }

      const whiteNoise = ctx.createBufferSource();
      whiteNoise.buffer = buffer;

      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(600, ctx.currentTime);
      filter.frequency.linearRampToValueAtTime(200, ctx.currentTime + 0.35);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.38);

      whiteNoise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      whiteNoise.start();

      // Follow with fairy sparkle
      setTimeout(() => {
        this.playBellTone(1046.5, 0.6, 0.8);
      }, 250);
    } catch {
      // Audio error ignored
    }
  }

  // Funny cartoon whistle / boing for wrong gift
  public playBuzzer() {
    const ctx = this.getContext();
    if (!ctx || this.isMuted) return;

    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const now = ctx.currentTime;

      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(400, now);
      osc.frequency.exponentialRampToValueAtTime(120, now + 0.35);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.36);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.38);
    } catch {
      // Handled
    }
  }

  // Sparkle tone
  public playSparkle() {
    this.playBellTone(1174.66, 0.3, 0.5); // D6
  }
}

export const soundManager = new SoundController();
