import React, { useState } from "react";
import { initialBirthdayConfig, BirthdayConfig } from "./birthdayConfig";
import { NavigationHeader } from "./components/NavigationHeader";
import { DecorativeBackground } from "./components/DecorativeBackground";
import { ScreenIntro } from "./components/ScreenIntro";
import { ScreenMakeAWish } from "./components/ScreenMakeAWish";
import { ScreenBirthdayCard } from "./components/ScreenBirthdayCard";
import { ScreenGiftBoxes } from "./components/ScreenGiftBoxes";
import { ScreenWrongGift } from "./components/ScreenWrongGift";
import { ScreenMemories } from "./components/ScreenMemories";
import { ScreenLetter } from "./components/ScreenLetter";
import { ScreenCelebration } from "./components/ScreenCelebration";
import { CustomizeModal } from "./components/CustomizeModal";
import { soundManager } from "./utils/audio";

export default function App() {
  const [config, setConfig] = useState<BirthdayConfig>(initialBirthdayConfig);
  const [currentScreen, setCurrentScreen] = useState<number>(1);
  const [isCustomizeOpen, setIsCustomizeOpen] = useState<boolean>(false);
  const [isMusicPlaying, setIsMusicPlaying] = useState<boolean>(false);

  const totalScreens = 8;

  // Handle first interaction: start music if user has not muted
  const handleFirstInteraction = () => {
    if (!isMusicPlaying) {
      soundManager.startMusic();
      setIsMusicPlaying(true);
    }
  };

  const handleNextScreen = () => {
    handleFirstInteraction();
    setCurrentScreen((prev) => Math.min(prev + 1, totalScreens));
  };

  const handleRestart = () => {
    setCurrentScreen(1);
  };

  return (
    <div className="min-h-screen bg-[#FFFDF5] font-body selection:bg-[#F8D9DC] selection:text-[#C94343]">
      {/* Top Header with Navigation & Music Controls */}
      <NavigationHeader
        currentScreen={currentScreen}
        totalScreens={totalScreens}
        onSelectScreen={(screen) => setCurrentScreen(screen)}
        onOpenCustomize={() => setIsCustomizeOpen(true)}
        onRestart={handleRestart}
        isMusicPlaying={isMusicPlaying}
        setIsMusicPlaying={setIsMusicPlaying}
      />

      {/* Main Decorated Background Container */}
      <DecorativeBackground>
        {/* SCREEN 1: Introduction / Surprise Question */}
        {currentScreen === 1 && (
          <ScreenIntro
            onYes={handleNextScreen}
            introImage={config.INTRO_CARTOON}
          />
        )}

        {/* SCREEN 2: Make a Wish */}
        {currentScreen === 2 && (
          <ScreenMakeAWish
            onContinue={handleNextScreen}
            recipientName={config.RECIPIENT_NAME}
          />
        )}

        {/* SCREEN 3: Personalized Happy Birthday Card */}
        {currentScreen === 3 && (
          <ScreenBirthdayCard
            onContinue={handleNextScreen}
            recipientName={config.RECIPIENT_NAME}
            recipientPhoto={config.RECIPIENT_PHOTO}
            birthdayMessage={config.BIRTHDAY_MESSAGE}
            cartoonImage={config.INTRO_CARTOON}
          />
        )}

        {/* SCREEN 4: Interactive Gift Boxes */}
        {currentScreen === 4 && (
          <ScreenGiftBoxes
            onProceedToGallery={() => setCurrentScreen(6)}
            onTriggerWrongGift={() => setCurrentScreen(5)}
            gift1Title={config.GIFT_1_TITLE}
            gift1Message={config.GIFT_1_MESSAGE}
            gift2Title={config.GIFT_2_TITLE}
            gift2Message={config.GIFT_2_MESSAGE}
            gift2Photo={config.GIFT_2_PHOTO}
            gift3Title={config.GIFT_3_TITLE}
            gift3Message={config.GIFT_3_MESSAGE}
            recipientName={config.RECIPIENT_NAME}
          />
        )}

        {/* SCREEN 5: Funny Wrong Gift Screen */}
        {currentScreen === 5 && (
          <ScreenWrongGift
            onTryAgain={() => setCurrentScreen(4)}
            shockedImage={config.SHOCKED_CARTOON}
          />
        )}

        {/* SCREEN 6: Memories Gallery */}
        {currentScreen === 6 && (
          <ScreenMemories
            onContinue={() => setCurrentScreen(7)}
            memories={config.MEMORY_PHOTOS}
          />
        )}

        {/* SCREEN 7: Personalized Letter */}
        {currentScreen === 7 && (
          <ScreenLetter
            onContinue={() => setCurrentScreen(8)}
            recipientName={config.RECIPIENT_NAME}
            yourName={config.YOUR_NAME}
            letterTitle={config.LETTER_TITLE}
            letterParagraphs={config.LETTER_PARAGRAPHS}
            cartoonImage={config.INTRO_CARTOON}
          />
        )}

        {/* SCREEN 8: Final Birthday Celebration */}
        {currentScreen === 8 && (
          <ScreenCelebration
            onRestart={handleRestart}
            onGoToMemories={() => setCurrentScreen(6)}
            onGoToLetter={() => setCurrentScreen(7)}
            onOpenCustomize={() => setIsCustomizeOpen(true)}
            recipientName={config.RECIPIENT_NAME}
            yourName={config.YOUR_NAME}
          />
        )}
      </DecorativeBackground>

      {/* Live Customization Modal */}
      <CustomizeModal
        isOpen={isCustomizeOpen}
        onClose={() => setIsCustomizeOpen(false)}
        config={config}
        onSave={(updated) => setConfig(updated)}
        onReset={() => setConfig(initialBirthdayConfig)}
      />
    </div>
  );
}
